from .input_mutation import InputMutationExtension

__all__ = [
    "InputMutationExtension",
]
